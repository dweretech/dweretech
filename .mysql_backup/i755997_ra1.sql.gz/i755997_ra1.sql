-- MySQL dump 10.13  Distrib 5.5.41, for Linux (x86_64)
--
-- Host: localhost    Database: i755997_ra1
-- ------------------------------------------------------
-- Server version	5.5.41-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `i755997_ra1`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `i755997_ra1` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `i755997_ra1`;

--
-- Table structure for table `ra_account_preference_assoc`
--

DROP TABLE IF EXISTS `ra_account_preference_assoc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_account_preference_assoc` (
  `account_id` mediumint(9) NOT NULL,
  `preference_id` mediumint(9) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`account_id`,`preference_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_account_preference_assoc`
--

LOCK TABLES `ra_account_preference_assoc` WRITE;
/*!40000 ALTER TABLE `ra_account_preference_assoc` DISABLE KEYS */;
INSERT INTO `ra_account_preference_assoc` VALUES (1,1,''),(1,2,''),(1,3,'1'),(1,4,'1'),(1,5,'1'),(1,6,'100'),(1,7,'1'),(1,8,''),(1,9,''),(1,10,'1'),(1,11,'100'),(1,12,'1'),(1,13,'1'),(1,14,'100'),(1,15,'1'),(1,16,'America/Chicago'),(1,17,'4'),(1,18,'1'),(1,19,''),(1,20,'1'),(1,21,'1'),(1,22,''),(1,23,''),(1,24,'1'),(1,25,''),(1,26,'1'),(1,27,''),(1,28,''),(1,29,'1'),(1,30,'1'),(1,31,'2'),(1,32,'1'),(1,33,''),(1,34,'4'),(1,35,''),(1,36,''),(1,37,'0'),(1,38,''),(1,39,''),(1,40,'0'),(1,41,''),(1,42,''),(1,43,'0'),(1,44,''),(1,45,''),(1,46,'0'),(1,47,''),(1,48,''),(1,49,'0'),(1,50,''),(1,51,''),(1,52,'0'),(1,53,''),(1,54,''),(1,55,'0'),(1,56,''),(1,57,''),(1,58,'0'),(1,59,''),(1,60,''),(1,61,'0'),(1,62,'1'),(1,63,''),(1,64,'5'),(1,65,''),(1,66,''),(1,67,'0'),(1,68,''),(1,69,''),(1,70,'0'),(1,71,''),(1,72,''),(1,73,'0'),(1,74,''),(1,75,''),(1,76,'0'),(1,77,'1'),(1,78,''),(1,79,'1'),(1,80,'1'),(1,81,''),(1,82,'2'),(1,83,'1'),(1,84,''),(1,85,'3'),(1,86,''),(1,87,''),(1,88,'0'),(1,89,''),(1,90,''),(1,91,'0'),(1,92,''),(1,93,''),(1,94,'0'),(1,95,''),(1,96,''),(1,97,'0');
/*!40000 ALTER TABLE `ra_account_preference_assoc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_account_user_assoc`
--

DROP TABLE IF EXISTS `ra_account_user_assoc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_account_user_assoc` (
  `account_id` mediumint(9) NOT NULL,
  `user_id` mediumint(9) NOT NULL,
  `linked` datetime NOT NULL,
  PRIMARY KEY (`account_id`,`user_id`),
  KEY `ra_account_user_assoc_user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_account_user_assoc`
--

LOCK TABLES `ra_account_user_assoc` WRITE;
/*!40000 ALTER TABLE `ra_account_user_assoc` DISABLE KEYS */;
INSERT INTO `ra_account_user_assoc` VALUES (1,1,'2014-01-22 04:45:00'),(2,1,'2014-01-22 04:45:00');
/*!40000 ALTER TABLE `ra_account_user_assoc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_account_user_permission_assoc`
--

DROP TABLE IF EXISTS `ra_account_user_permission_assoc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_account_user_permission_assoc` (
  `account_id` mediumint(9) NOT NULL,
  `user_id` mediumint(9) NOT NULL,
  `permission_id` mediumint(9) NOT NULL,
  `is_allowed` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`account_id`,`user_id`,`permission_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_account_user_permission_assoc`
--

LOCK TABLES `ra_account_user_permission_assoc` WRITE;
/*!40000 ALTER TABLE `ra_account_user_permission_assoc` DISABLE KEYS */;
/*!40000 ALTER TABLE `ra_account_user_permission_assoc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_accounts`
--

DROP TABLE IF EXISTS `ra_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_accounts` (
  `account_id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `account_type` varchar(16) NOT NULL DEFAULT '',
  `account_name` varchar(255) DEFAULT NULL,
  `m2m_password` varchar(32) DEFAULT NULL,
  `m2m_ticket` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`account_id`),
  KEY `ra_accounts_account_type` (`account_type`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_accounts`
--

LOCK TABLES `ra_accounts` WRITE;
/*!40000 ALTER TABLE `ra_accounts` DISABLE KEYS */;
INSERT INTO `ra_accounts` VALUES (1,'ADMIN','Administrator account',NULL,NULL),(2,'MANAGER','Default manager',NULL,NULL);
/*!40000 ALTER TABLE `ra_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_acls`
--

DROP TABLE IF EXISTS `ra_acls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_acls` (
  `bannerid` mediumint(9) NOT NULL DEFAULT '0',
  `logical` varchar(3) NOT NULL DEFAULT 'and',
  `type` varchar(255) NOT NULL DEFAULT '',
  `comparison` char(2) NOT NULL DEFAULT '==',
  `data` text NOT NULL,
  `executionorder` int(10) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `ra_acls_bannerid_executionorder` (`bannerid`,`executionorder`),
  KEY `ra_acls_bannerid` (`bannerid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_acls`
--

LOCK TABLES `ra_acls` WRITE;
/*!40000 ALTER TABLE `ra_acls` DISABLE KEYS */;
/*!40000 ALTER TABLE `ra_acls` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_acls_channel`
--

DROP TABLE IF EXISTS `ra_acls_channel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_acls_channel` (
  `channelid` mediumint(9) NOT NULL DEFAULT '0',
  `logical` varchar(3) NOT NULL DEFAULT 'and',
  `type` varchar(255) NOT NULL DEFAULT '',
  `comparison` char(2) NOT NULL DEFAULT '==',
  `data` text NOT NULL,
  `executionorder` int(10) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `ra_acls_channel_channelid_executionorder` (`channelid`,`executionorder`),
  KEY `ra_acls_channel_channelid` (`channelid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_acls_channel`
--

LOCK TABLES `ra_acls_channel` WRITE;
/*!40000 ALTER TABLE `ra_acls_channel` DISABLE KEYS */;
/*!40000 ALTER TABLE `ra_acls_channel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_ad_category_assoc`
--

DROP TABLE IF EXISTS `ra_ad_category_assoc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_ad_category_assoc` (
  `ad_category_assoc_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(10) unsigned NOT NULL,
  `ad_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`ad_category_assoc_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_ad_category_assoc`
--

LOCK TABLES `ra_ad_category_assoc` WRITE;
/*!40000 ALTER TABLE `ra_ad_category_assoc` DISABLE KEYS */;
/*!40000 ALTER TABLE `ra_ad_category_assoc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_ad_zone_assoc`
--

DROP TABLE IF EXISTS `ra_ad_zone_assoc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_ad_zone_assoc` (
  `ad_zone_assoc_id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `zone_id` mediumint(9) DEFAULT NULL,
  `ad_id` mediumint(9) DEFAULT NULL,
  `priority` double DEFAULT '0',
  `link_type` smallint(6) NOT NULL DEFAULT '1',
  `priority_factor` double DEFAULT '0',
  `to_be_delivered` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`ad_zone_assoc_id`),
  KEY `ra_ad_zone_assoc_zone_id` (`zone_id`),
  KEY `ra_ad_zone_assoc_ad_id` (`ad_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_ad_zone_assoc`
--

LOCK TABLES `ra_ad_zone_assoc` WRITE;
/*!40000 ALTER TABLE `ra_ad_zone_assoc` DISABLE KEYS */;
/*!40000 ALTER TABLE `ra_ad_zone_assoc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_affiliates`
--

DROP TABLE IF EXISTS `ra_affiliates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_affiliates` (
  `affiliateid` mediumint(9) NOT NULL AUTO_INCREMENT,
  `agencyid` mediumint(9) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `mnemonic` varchar(5) NOT NULL DEFAULT '',
  `comments` text,
  `contact` varchar(255) DEFAULT NULL,
  `email` varchar(64) NOT NULL DEFAULT '',
  `website` varchar(255) DEFAULT NULL,
  `updated` datetime NOT NULL,
  `an_website_id` int(11) DEFAULT NULL,
  `oac_country_code` char(2) NOT NULL DEFAULT '',
  `oac_language_id` int(11) DEFAULT NULL,
  `oac_category_id` int(11) DEFAULT NULL,
  `as_website_id` int(11) DEFAULT NULL,
  `account_id` mediumint(9) DEFAULT NULL,
  PRIMARY KEY (`affiliateid`),
  UNIQUE KEY `ra_affiliates_account_id` (`account_id`),
  KEY `ra_affiliates_agencyid` (`agencyid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_affiliates`
--

LOCK TABLES `ra_affiliates` WRITE;
/*!40000 ALTER TABLE `ra_affiliates` DISABLE KEYS */;
/*!40000 ALTER TABLE `ra_affiliates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_affiliates_extra`
--

DROP TABLE IF EXISTS `ra_affiliates_extra`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_affiliates_extra` (
  `affiliateid` mediumint(9) NOT NULL,
  `address` text,
  `city` varchar(255) DEFAULT NULL,
  `postcode` varchar(64) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `phone` varchar(64) DEFAULT NULL,
  `fax` varchar(64) DEFAULT NULL,
  `account_contact` varchar(255) DEFAULT NULL,
  `payee_name` varchar(255) DEFAULT NULL,
  `tax_id` varchar(64) DEFAULT NULL,
  `mode_of_payment` varchar(64) DEFAULT NULL,
  `currency` varchar(64) DEFAULT NULL,
  `unique_users` int(11) DEFAULT NULL,
  `unique_views` int(11) DEFAULT NULL,
  `page_rank` int(11) DEFAULT NULL,
  `category` varchar(255) DEFAULT NULL,
  `help_file` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`affiliateid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_affiliates_extra`
--

LOCK TABLES `ra_affiliates_extra` WRITE;
/*!40000 ALTER TABLE `ra_affiliates_extra` DISABLE KEYS */;
/*!40000 ALTER TABLE `ra_affiliates_extra` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_agency`
--

DROP TABLE IF EXISTS `ra_agency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_agency` (
  `agencyid` mediumint(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `contact` varchar(255) DEFAULT NULL,
  `email` varchar(64) NOT NULL DEFAULT '',
  `logout_url` varchar(255) DEFAULT NULL,
  `active` smallint(1) DEFAULT '0',
  `updated` datetime NOT NULL,
  `account_id` mediumint(9) DEFAULT NULL,
  PRIMARY KEY (`agencyid`),
  UNIQUE KEY `ra_agency_account_id` (`account_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_agency`
--

LOCK TABLES `ra_agency` WRITE;
/*!40000 ALTER TABLE `ra_agency` DISABLE KEYS */;
INSERT INTO `ra_agency` VALUES (1,'Default manager',NULL,'devnull@installatron.com',NULL,1,'2014-01-22 10:45:00',2);
/*!40000 ALTER TABLE `ra_agency` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_application_variable`
--

DROP TABLE IF EXISTS `ra_application_variable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_application_variable` (
  `name` varchar(255) NOT NULL DEFAULT '',
  `value` text NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_application_variable`
--

LOCK TABLES `ra_application_variable` WRITE;
/*!40000 ALTER TABLE `ra_application_variable` DISABLE KEYS */;
INSERT INTO `ra_application_variable` VALUES ('tables_core','613'),('oa_version','3.0.5'),('admin_account_id','1'),('oxHtml_version','1.2.1'),('oxText_version','1.2.1'),('Client_version','1.2.1'),('Geo_version','1.2.1'),('Site_version','1.2.1'),('Time_version','1.2.1'),('ox3rdPartyServers_version','1.1.0'),('oxReportsStandard_version','1.5.1'),('oxReportsAdmin_version','1.5.1'),('oxCacheFile_version','1.1.1'),('oxMemcached_version','1.1.1'),('oxMaxMindGeoIP_version','1.2.2'),('oxInvocationTags_version','1.2.1'),('tables_oxDeliveryDataPrepare','002'),('oxDeliveryDataPrepare_version','1.1.1'),('oxLogClick_version','1.1.1'),('oxLogConversion_version','1.1.1'),('oxLogImpression_version','1.1.1'),('oxLogRequest_version','1.1.1'),('tables_vastbannertypehtml','013'),('vastInlineBannerTypeHtml_version','1.10.2'),('vastOverlayBannerTypeHtml_version','1.10.2'),('oxLogVast_version','1.10.2'),('vastServeVideoPlayer_version','1.10.2'),('videoReport_version','1.10.2');
/*!40000 ALTER TABLE `ra_application_variable` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_audit`
--

DROP TABLE IF EXISTS `ra_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_audit` (
  `auditid` mediumint(9) NOT NULL AUTO_INCREMENT,
  `actionid` mediumint(9) NOT NULL,
  `context` varchar(255) NOT NULL DEFAULT '',
  `contextid` mediumint(9) DEFAULT NULL,
  `parentid` mediumint(9) DEFAULT NULL,
  `details` text NOT NULL,
  `userid` mediumint(9) NOT NULL DEFAULT '0',
  `username` varchar(64) DEFAULT NULL,
  `usertype` tinyint(4) NOT NULL DEFAULT '0',
  `updated` datetime DEFAULT NULL,
  `account_id` mediumint(9) NOT NULL,
  `advertiser_account_id` mediumint(9) DEFAULT NULL,
  `website_account_id` mediumint(9) DEFAULT NULL,
  PRIMARY KEY (`auditid`),
  KEY `ra_audit_parentid_contextid` (`parentid`,`contextid`),
  KEY `ra_audit_updated` (`updated`),
  KEY `ra_audit_usertype` (`usertype`),
  KEY `ra_audit_username` (`username`),
  KEY `ra_audit_context_actionid` (`context`,`actionid`),
  KEY `ra_audit_account_id` (`account_id`),
  KEY `ra_audit_advertiser_account_id` (`advertiser_account_id`),
  KEY `ra_audit_website_account_id` (`website_account_id`)
) ENGINE=MyISAM AUTO_INCREMENT=204 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_audit`
--

LOCK TABLES `ra_audit` WRITE;
/*!40000 ALTER TABLE `ra_audit` DISABLE KEYS */;
INSERT INTO `ra_audit` VALUES (203,2,'users',1,NULL,'a:2:{s:15:\"date_last_login\";a:2:{s:3:\"was\";s:19:\"2014-01-23 02:29:25\";s:2:\"is\";s:19:\"2015-03-21 02:36:44\";}s:8:\"key_desc\";N;}',0,NULL,0,'2015-03-21 02:36:44',1,NULL,NULL);
/*!40000 ALTER TABLE `ra_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_banner_vast_element`
--

DROP TABLE IF EXISTS `ra_banner_vast_element`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_banner_vast_element` (
  `banner_vast_element_id` mediumint(9) NOT NULL,
  `banner_id` mediumint(9) NOT NULL,
  `vast_element_type` varchar(16) NOT NULL DEFAULT '',
  `vast_video_id` varchar(100) DEFAULT NULL,
  `vast_video_duration` mediumint(9) DEFAULT NULL,
  `vast_video_delivery` varchar(20) DEFAULT NULL,
  `vast_video_type` varchar(20) DEFAULT NULL,
  `vast_video_bitrate` varchar(20) DEFAULT NULL,
  `vast_video_height` mediumint(9) DEFAULT NULL,
  `vast_video_width` mediumint(9) DEFAULT NULL,
  `vast_video_outgoing_filename` text,
  `vast_companion_banner_id` mediumint(9) DEFAULT NULL,
  `vast_overlay_height` mediumint(9) DEFAULT NULL,
  `vast_overlay_width` mediumint(9) DEFAULT NULL,
  `vast_video_clickthrough_url` text,
  `vast_overlay_action` varchar(20) DEFAULT NULL,
  `vast_overlay_format` varchar(20) DEFAULT NULL,
  `vast_overlay_text_title` text,
  `vast_overlay_text_description` text,
  `vast_overlay_text_call` text,
  `vast_creative_type` varchar(20) DEFAULT NULL,
  `vast_thirdparty_impression` text,
  KEY `ra_banner_vast_element_banner_vast_banner_vast_element_id` (`banner_vast_element_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_banner_vast_element`
--

LOCK TABLES `ra_banner_vast_element` WRITE;
/*!40000 ALTER TABLE `ra_banner_vast_element` DISABLE KEYS */;
/*!40000 ALTER TABLE `ra_banner_vast_element` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_banners`
--

DROP TABLE IF EXISTS `ra_banners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_banners` (
  `bannerid` mediumint(9) NOT NULL AUTO_INCREMENT,
  `campaignid` mediumint(9) NOT NULL DEFAULT '0',
  `contenttype` enum('gif','jpeg','png','html','swf','dcr','rpm','mov','txt') NOT NULL DEFAULT 'gif',
  `pluginversion` mediumint(9) NOT NULL DEFAULT '0',
  `storagetype` enum('sql','web','url','html','network','txt') NOT NULL DEFAULT 'sql',
  `filename` varchar(255) NOT NULL DEFAULT '',
  `imageurl` varchar(255) NOT NULL DEFAULT '',
  `htmltemplate` text NOT NULL,
  `htmlcache` text NOT NULL,
  `width` smallint(6) NOT NULL DEFAULT '0',
  `height` smallint(6) NOT NULL DEFAULT '0',
  `weight` tinyint(4) NOT NULL DEFAULT '1',
  `seq` tinyint(4) NOT NULL DEFAULT '0',
  `target` varchar(16) NOT NULL DEFAULT '',
  `url` text NOT NULL,
  `alt` varchar(255) NOT NULL DEFAULT '',
  `statustext` varchar(255) NOT NULL DEFAULT '',
  `bannertext` text NOT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  `adserver` varchar(255) NOT NULL DEFAULT '',
  `block` int(11) NOT NULL DEFAULT '0',
  `capping` int(11) NOT NULL DEFAULT '0',
  `session_capping` int(11) NOT NULL DEFAULT '0',
  `compiledlimitation` text NOT NULL,
  `acl_plugins` text,
  `append` text NOT NULL,
  `bannertype` tinyint(4) NOT NULL DEFAULT '0',
  `alt_filename` varchar(255) NOT NULL DEFAULT '',
  `alt_imageurl` varchar(255) NOT NULL DEFAULT '',
  `alt_contenttype` enum('gif','jpeg','png') NOT NULL DEFAULT 'gif',
  `comments` text,
  `updated` datetime NOT NULL,
  `acls_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `keyword` varchar(255) NOT NULL DEFAULT '',
  `transparent` tinyint(1) NOT NULL DEFAULT '0',
  `parameters` text,
  `an_banner_id` int(11) DEFAULT NULL,
  `as_banner_id` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `ad_direct_status` tinyint(4) NOT NULL DEFAULT '0',
  `ad_direct_rejection_reason_id` tinyint(4) NOT NULL DEFAULT '0',
  `ext_bannertype` varchar(255) DEFAULT NULL,
  `prepend` text NOT NULL,
  PRIMARY KEY (`bannerid`),
  KEY `ra_banners_campaignid` (`campaignid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_banners`
--

LOCK TABLES `ra_banners` WRITE;
/*!40000 ALTER TABLE `ra_banners` DISABLE KEYS */;
/*!40000 ALTER TABLE `ra_banners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_campaigns`
--

DROP TABLE IF EXISTS `ra_campaigns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_campaigns` (
  `campaignid` mediumint(9) NOT NULL AUTO_INCREMENT,
  `campaignname` varchar(255) NOT NULL DEFAULT '',
  `clientid` mediumint(9) NOT NULL DEFAULT '0',
  `views` int(11) DEFAULT '-1',
  `clicks` int(11) DEFAULT '-1',
  `conversions` int(11) DEFAULT '-1',
  `priority` int(11) NOT NULL DEFAULT '0',
  `weight` tinyint(4) NOT NULL DEFAULT '1',
  `target_impression` int(11) NOT NULL DEFAULT '0',
  `target_click` int(11) NOT NULL DEFAULT '0',
  `target_conversion` int(11) NOT NULL DEFAULT '0',
  `anonymous` enum('t','f') NOT NULL DEFAULT 'f',
  `companion` smallint(1) DEFAULT '0',
  `comments` text,
  `revenue` decimal(10,4) DEFAULT NULL,
  `revenue_type` smallint(6) DEFAULT NULL,
  `updated` datetime NOT NULL,
  `block` int(11) NOT NULL DEFAULT '0',
  `capping` int(11) NOT NULL DEFAULT '0',
  `session_capping` int(11) NOT NULL DEFAULT '0',
  `an_campaign_id` int(11) DEFAULT NULL,
  `as_campaign_id` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `an_status` int(11) NOT NULL DEFAULT '0',
  `as_reject_reason` int(11) NOT NULL DEFAULT '0',
  `hosted_views` int(11) NOT NULL DEFAULT '0',
  `hosted_clicks` int(11) NOT NULL DEFAULT '0',
  `viewwindow` mediumint(9) NOT NULL DEFAULT '0',
  `clickwindow` mediumint(9) NOT NULL DEFAULT '0',
  `ecpm` decimal(10,4) DEFAULT NULL,
  `min_impressions` int(11) NOT NULL DEFAULT '0',
  `ecpm_enabled` tinyint(4) NOT NULL DEFAULT '0',
  `activate_time` datetime DEFAULT NULL,
  `expire_time` datetime DEFAULT NULL,
  `type` tinyint(4) NOT NULL DEFAULT '0',
  `show_capped_no_cookie` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`campaignid`),
  KEY `ra_campaigns_clientid` (`clientid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_campaigns`
--

LOCK TABLES `ra_campaigns` WRITE;
/*!40000 ALTER TABLE `ra_campaigns` DISABLE KEYS */;
/*!40000 ALTER TABLE `ra_campaigns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_campaigns_trackers`
--

DROP TABLE IF EXISTS `ra_campaigns_trackers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_campaigns_trackers` (
  `campaign_trackerid` mediumint(9) NOT NULL AUTO_INCREMENT,
  `campaignid` mediumint(9) NOT NULL DEFAULT '0',
  `trackerid` mediumint(9) NOT NULL DEFAULT '0',
  `status` smallint(1) unsigned NOT NULL DEFAULT '4',
  PRIMARY KEY (`campaign_trackerid`),
  KEY `ra_campaigns_trackers_campaignid` (`campaignid`),
  KEY `ra_campaigns_trackers_trackerid` (`trackerid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_campaigns_trackers`
--

LOCK TABLES `ra_campaigns_trackers` WRITE;
/*!40000 ALTER TABLE `ra_campaigns_trackers` DISABLE KEYS */;
/*!40000 ALTER TABLE `ra_campaigns_trackers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_category`
--

DROP TABLE IF EXISTS `ra_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_category` (
  `category_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_category`
--

LOCK TABLES `ra_category` WRITE;
/*!40000 ALTER TABLE `ra_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `ra_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_channel`
--

DROP TABLE IF EXISTS `ra_channel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_channel` (
  `channelid` mediumint(9) NOT NULL AUTO_INCREMENT,
  `agencyid` mediumint(9) NOT NULL DEFAULT '0',
  `affiliateid` mediumint(9) NOT NULL DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `compiledlimitation` text NOT NULL,
  `acl_plugins` text,
  `active` smallint(1) DEFAULT NULL,
  `comments` text,
  `updated` datetime NOT NULL,
  `acls_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`channelid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_channel`
--

LOCK TABLES `ra_channel` WRITE;
/*!40000 ALTER TABLE `ra_channel` DISABLE KEYS */;
/*!40000 ALTER TABLE `ra_channel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_clients`
--

DROP TABLE IF EXISTS `ra_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_clients` (
  `clientid` mediumint(9) NOT NULL AUTO_INCREMENT,
  `agencyid` mediumint(9) NOT NULL DEFAULT '0',
  `clientname` varchar(255) NOT NULL DEFAULT '',
  `contact` varchar(255) DEFAULT NULL,
  `email` varchar(64) NOT NULL DEFAULT '',
  `report` enum('t','f') NOT NULL DEFAULT 't',
  `reportinterval` mediumint(9) NOT NULL DEFAULT '7',
  `reportlastdate` date NOT NULL DEFAULT '0000-00-00',
  `reportdeactivate` enum('t','f') NOT NULL DEFAULT 't',
  `comments` text,
  `updated` datetime NOT NULL,
  `an_adnetwork_id` int(11) DEFAULT NULL,
  `as_advertiser_id` int(11) DEFAULT NULL,
  `account_id` mediumint(9) DEFAULT NULL,
  `advertiser_limitation` tinyint(1) NOT NULL DEFAULT '0',
  `type` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`clientid`),
  UNIQUE KEY `ra_clients_account_id` (`account_id`),
  KEY `ra_clients_agencyid_type` (`agencyid`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_clients`
--

LOCK TABLES `ra_clients` WRITE;
/*!40000 ALTER TABLE `ra_clients` DISABLE KEYS */;
/*!40000 ALTER TABLE `ra_clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_data_bkt_a`
--

DROP TABLE IF EXISTS `ra_data_bkt_a`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_data_bkt_a` (
  `server_conv_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `server_ip` varchar(16) NOT NULL DEFAULT '',
  `tracker_id` mediumint(9) NOT NULL,
  `date_time` datetime NOT NULL,
  `action_date_time` datetime NOT NULL,
  `creative_id` mediumint(9) NOT NULL,
  `zone_id` mediumint(9) NOT NULL,
  `ip_address` varchar(16) NOT NULL DEFAULT '',
  `action` int(10) DEFAULT NULL,
  `window` int(10) DEFAULT NULL,
  `status` int(10) DEFAULT NULL,
  PRIMARY KEY (`server_conv_id`,`server_ip`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_data_bkt_a`
--

LOCK TABLES `ra_data_bkt_a` WRITE;
/*!40000 ALTER TABLE `ra_data_bkt_a` DISABLE KEYS */;
/*!40000 ALTER TABLE `ra_data_bkt_a` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_data_bkt_a_var`
--

DROP TABLE IF EXISTS `ra_data_bkt_a_var`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_data_bkt_a_var` (
  `server_conv_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `server_ip` varchar(16) NOT NULL DEFAULT '',
  `tracker_variable_id` mediumint(9) NOT NULL,
  `value` text,
  `date_time` datetime NOT NULL,
  PRIMARY KEY (`server_conv_id`,`server_ip`,`tracker_variable_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_data_bkt_a_var`
--

LOCK TABLES `ra_data_bkt_a_var` WRITE;
/*!40000 ALTER TABLE `ra_data_bkt_a_var` DISABLE KEYS */;
/*!40000 ALTER TABLE `ra_data_bkt_a_var` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_data_bkt_c`
--

DROP TABLE IF EXISTS `ra_data_bkt_c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_data_bkt_c` (
  `interval_start` datetime NOT NULL,
  `creative_id` mediumint(9) NOT NULL,
  `zone_id` mediumint(9) NOT NULL,
  `count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`interval_start`,`creative_id`,`zone_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_data_bkt_c`
--

LOCK TABLES `ra_data_bkt_c` WRITE;
/*!40000 ALTER TABLE `ra_data_bkt_c` DISABLE KEYS */;
/*!40000 ALTER TABLE `ra_data_bkt_c` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_data_bkt_m`
--

DROP TABLE IF EXISTS `ra_data_bkt_m`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_data_bkt_m` (
  `interval_start` datetime NOT NULL,
  `creative_id` mediumint(9) NOT NULL,
  `zone_id` mediumint(9) NOT NULL,
  `count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`interval_start`,`creative_id`,`zone_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_data_bkt_m`
--

LOCK TABLES `ra_data_bkt_m` WRITE;
/*!40000 ALTER TABLE `ra_data_bkt_m` DISABLE KEYS */;
/*!40000 ALTER TABLE `ra_data_bkt_m` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_data_bkt_r`
--

DROP TABLE IF EXISTS `ra_data_bkt_r`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_data_bkt_r` (
  `interval_start` datetime NOT NULL,
  `creative_id` mediumint(9) NOT NULL,
  `zone_id` mediumint(9) NOT NULL,
  `count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`interval_start`,`creative_id`,`zone_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_data_bkt_r`
--

LOCK TABLES `ra_data_bkt_r` WRITE;
/*!40000 ALTER TABLE `ra_data_bkt_r` DISABLE KEYS */;
/*!40000 ALTER TABLE `ra_data_bkt_r` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_data_bkt_vast_e`
--

DROP TABLE IF EXISTS `ra_data_bkt_vast_e`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_data_bkt_vast_e` (
  `interval_start` datetime NOT NULL,
  `creative_id` mediumint(20) NOT NULL,
  `zone_id` mediumint(20) NOT NULL,
  `vast_event_id` mediumint(20) NOT NULL,
  `count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`interval_start`,`creative_id`,`zone_id`,`vast_event_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_data_bkt_vast_e`
--

LOCK TABLES `ra_data_bkt_vast_e` WRITE;
/*!40000 ALTER TABLE `ra_data_bkt_vast_e` DISABLE KEYS */;
/*!40000 ALTER TABLE `ra_data_bkt_vast_e` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_data_intermediate_ad`
--

DROP TABLE IF EXISTS `ra_data_intermediate_ad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_data_intermediate_ad` (
  `data_intermediate_ad_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date_time` datetime NOT NULL,
  `operation_interval` int(10) unsigned NOT NULL,
  `operation_interval_id` int(10) unsigned NOT NULL,
  `interval_start` datetime NOT NULL,
  `interval_end` datetime NOT NULL,
  `ad_id` int(10) unsigned NOT NULL,
  `creative_id` int(10) unsigned NOT NULL,
  `zone_id` int(10) unsigned NOT NULL,
  `requests` int(10) unsigned NOT NULL DEFAULT '0',
  `impressions` int(10) unsigned NOT NULL DEFAULT '0',
  `clicks` int(10) unsigned NOT NULL DEFAULT '0',
  `conversions` int(10) unsigned NOT NULL DEFAULT '0',
  `total_basket_value` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `total_num_items` int(11) NOT NULL DEFAULT '0',
  `updated` datetime NOT NULL,
  PRIMARY KEY (`data_intermediate_ad_id`),
  KEY `ra_data_intermediate_ad_ad_id_date_time` (`ad_id`,`date_time`),
  KEY `ra_data_intermediate_ad_zone_id_date_time` (`zone_id`,`date_time`),
  KEY `ra_data_intermediate_ad_date_time` (`date_time`),
  KEY `ra_data_intermediate_ad_interval_start` (`interval_start`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_data_intermediate_ad`
--

LOCK TABLES `ra_data_intermediate_ad` WRITE;
/*!40000 ALTER TABLE `ra_data_intermediate_ad` DISABLE KEYS */;
/*!40000 ALTER TABLE `ra_data_intermediate_ad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_data_intermediate_ad_connection`
--

DROP TABLE IF EXISTS `ra_data_intermediate_ad_connection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_data_intermediate_ad_connection` (
  `data_intermediate_ad_connection_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `server_raw_ip` varchar(16) NOT NULL DEFAULT '',
  `server_raw_tracker_impression_id` bigint(20) NOT NULL,
  `viewer_id` varchar(32) DEFAULT NULL,
  `viewer_session_id` varchar(32) DEFAULT NULL,
  `tracker_date_time` datetime NOT NULL,
  `connection_date_time` datetime DEFAULT NULL,
  `tracker_id` int(10) unsigned NOT NULL,
  `ad_id` int(10) unsigned NOT NULL,
  `creative_id` int(10) unsigned NOT NULL,
  `zone_id` int(10) unsigned NOT NULL,
  `tracker_channel` varchar(255) DEFAULT NULL,
  `connection_channel` varchar(255) DEFAULT NULL,
  `tracker_channel_ids` varchar(64) DEFAULT NULL,
  `connection_channel_ids` varchar(64) DEFAULT NULL,
  `tracker_language` varchar(13) DEFAULT NULL,
  `connection_language` varchar(13) DEFAULT NULL,
  `tracker_ip_address` varchar(16) DEFAULT NULL,
  `connection_ip_address` varchar(16) DEFAULT NULL,
  `tracker_host_name` varchar(255) DEFAULT NULL,
  `connection_host_name` varchar(255) DEFAULT NULL,
  `tracker_country` char(2) DEFAULT NULL,
  `connection_country` char(2) DEFAULT NULL,
  `tracker_https` int(10) unsigned DEFAULT NULL,
  `connection_https` int(10) unsigned DEFAULT NULL,
  `tracker_domain` varchar(255) DEFAULT NULL,
  `connection_domain` varchar(255) DEFAULT NULL,
  `tracker_page` varchar(255) DEFAULT NULL,
  `connection_page` varchar(255) DEFAULT NULL,
  `tracker_query` varchar(255) DEFAULT NULL,
  `connection_query` varchar(255) DEFAULT NULL,
  `tracker_referer` varchar(255) DEFAULT NULL,
  `connection_referer` varchar(255) DEFAULT NULL,
  `tracker_search_term` varchar(255) DEFAULT NULL,
  `connection_search_term` varchar(255) DEFAULT NULL,
  `tracker_user_agent` varchar(255) DEFAULT NULL,
  `connection_user_agent` varchar(255) DEFAULT NULL,
  `tracker_os` varchar(32) DEFAULT NULL,
  `connection_os` varchar(32) DEFAULT NULL,
  `tracker_browser` varchar(32) DEFAULT NULL,
  `connection_browser` varchar(32) DEFAULT NULL,
  `connection_action` int(10) unsigned DEFAULT NULL,
  `connection_window` int(10) unsigned DEFAULT NULL,
  `connection_status` int(10) unsigned NOT NULL DEFAULT '4',
  `inside_window` tinyint(1) NOT NULL DEFAULT '0',
  `comments` text,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`data_intermediate_ad_connection_id`),
  KEY `ra_data_intermediate_ad_connection_tracker_date_time` (`tracker_date_time`),
  KEY `ra_data_intermediate_ad_connection_tracker_id` (`tracker_id`),
  KEY `ra_data_intermediate_ad_connection_ad_id` (`ad_id`),
  KEY `ra_data_intermediate_ad_connection_zone_id` (`zone_id`),
  KEY `ra_data_intermediate_ad_connection_viewer_id` (`viewer_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_data_intermediate_ad_connection`
--

LOCK TABLES `ra_data_intermediate_ad_connection` WRITE;
/*!40000 ALTER TABLE `ra_data_intermediate_ad_connection` DISABLE KEYS */;
/*!40000 ALTER TABLE `ra_data_intermediate_ad_connection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_data_intermediate_ad_variable_value`
--

DROP TABLE IF EXISTS `ra_data_intermediate_ad_variable_value`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_data_intermediate_ad_variable_value` (
  `data_intermediate_ad_variable_value_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `data_intermediate_ad_connection_id` bigint(20) NOT NULL,
  `tracker_variable_id` int(11) NOT NULL,
  `value` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`data_intermediate_ad_variable_value_id`),
  KEY `ra_data_intermediate_ad_variable_value_data_intermediate_ad_con` (`data_intermediate_ad_connection_id`),
  KEY `ra_data_intermediate_ad_variable_value_tracker_variable_id` (`tracker_variable_id`),
  KEY `ra_data_intermediate_ad_variable_value_tracker_value` (`value`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_data_intermediate_ad_variable_value`
--

LOCK TABLES `ra_data_intermediate_ad_variable_value` WRITE;
/*!40000 ALTER TABLE `ra_data_intermediate_ad_variable_value` DISABLE KEYS */;
/*!40000 ALTER TABLE `ra_data_intermediate_ad_variable_value` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_data_raw_ad_click`
--

DROP TABLE IF EXISTS `ra_data_raw_ad_click`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_data_raw_ad_click` (
  `viewer_id` varchar(32) DEFAULT NULL,
  `viewer_session_id` varchar(32) DEFAULT NULL,
  `date_time` datetime NOT NULL,
  `ad_id` int(10) unsigned NOT NULL,
  `creative_id` int(10) unsigned NOT NULL,
  `zone_id` int(10) unsigned NOT NULL,
  `channel` varchar(255) DEFAULT NULL,
  `channel_ids` varchar(64) DEFAULT NULL,
  `language` varchar(32) DEFAULT NULL,
  `ip_address` varchar(16) DEFAULT NULL,
  `host_name` varchar(255) DEFAULT NULL,
  `country` char(2) DEFAULT NULL,
  `https` tinyint(1) DEFAULT NULL,
  `domain` varchar(255) DEFAULT NULL,
  `page` varchar(255) DEFAULT NULL,
  `query` varchar(255) DEFAULT NULL,
  `referer` varchar(255) DEFAULT NULL,
  `search_term` varchar(255) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `os` varchar(32) DEFAULT NULL,
  `browser` varchar(32) DEFAULT NULL,
  `max_https` tinyint(1) DEFAULT NULL,
  `geo_region` varchar(50) DEFAULT NULL,
  `geo_city` varchar(50) DEFAULT NULL,
  `geo_postal_code` varchar(10) DEFAULT NULL,
  `geo_latitude` decimal(8,4) DEFAULT NULL,
  `geo_longitude` decimal(8,4) DEFAULT NULL,
  `geo_dma_code` varchar(50) DEFAULT NULL,
  `geo_area_code` varchar(50) DEFAULT NULL,
  `geo_organisation` varchar(50) DEFAULT NULL,
  `geo_netspeed` varchar(20) DEFAULT NULL,
  `geo_continent` varchar(13) DEFAULT NULL,
  KEY `ra_data_raw_ad_click_viewer_id` (`viewer_id`),
  KEY `ra_data_raw_ad_click_date_time` (`date_time`),
  KEY `ra_data_raw_ad_click_ad_id` (`ad_id`),
  KEY `ra_data_raw_ad_click_zone_id` (`zone_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_data_raw_ad_click`
--

LOCK TABLES `ra_data_raw_ad_click` WRITE;
/*!40000 ALTER TABLE `ra_data_raw_ad_click` DISABLE KEYS */;
/*!40000 ALTER TABLE `ra_data_raw_ad_click` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_data_raw_ad_impression`
--

DROP TABLE IF EXISTS `ra_data_raw_ad_impression`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_data_raw_ad_impression` (
  `viewer_id` varchar(32) DEFAULT NULL,
  `viewer_session_id` varchar(32) DEFAULT NULL,
  `date_time` datetime NOT NULL,
  `ad_id` int(10) unsigned NOT NULL,
  `creative_id` int(10) unsigned NOT NULL,
  `zone_id` int(10) unsigned NOT NULL,
  `channel` varchar(255) DEFAULT NULL,
  `channel_ids` varchar(64) DEFAULT NULL,
  `language` varchar(32) DEFAULT NULL,
  `ip_address` varchar(16) DEFAULT NULL,
  `host_name` varchar(255) DEFAULT NULL,
  `country` char(2) DEFAULT NULL,
  `https` tinyint(1) DEFAULT NULL,
  `domain` varchar(255) DEFAULT NULL,
  `page` varchar(255) DEFAULT NULL,
  `query` varchar(255) DEFAULT NULL,
  `referer` varchar(255) DEFAULT NULL,
  `search_term` varchar(255) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `os` varchar(32) DEFAULT NULL,
  `browser` varchar(32) DEFAULT NULL,
  `max_https` tinyint(1) DEFAULT NULL,
  `geo_region` varchar(50) DEFAULT NULL,
  `geo_city` varchar(50) DEFAULT NULL,
  `geo_postal_code` varchar(10) DEFAULT NULL,
  `geo_latitude` decimal(8,4) DEFAULT NULL,
  `geo_longitude` decimal(8,4) DEFAULT NULL,
  `geo_dma_code` varchar(50) DEFAULT NULL,
  `geo_area_code` varchar(50) DEFAULT NULL,
  `geo_organisation` varchar(50) DEFAULT NULL,
  `geo_netspeed` varchar(20) DEFAULT NULL,
  `geo_continent` varchar(13) DEFAULT NULL,
  KEY `ra_data_raw_ad_impression_viewer_id` (`viewer_id`),
  KEY `ra_data_raw_ad_impression_date_time` (`date_time`),
  KEY `ra_data_raw_ad_impression_ad_id` (`ad_id`),
  KEY `ra_data_raw_ad_impression_zone_id` (`zone_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_data_raw_ad_impression`
--

LOCK TABLES `ra_data_raw_ad_impression` WRITE;
/*!40000 ALTER TABLE `ra_data_raw_ad_impression` DISABLE KEYS */;
/*!40000 ALTER TABLE `ra_data_raw_ad_impression` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_data_raw_ad_request`
--

DROP TABLE IF EXISTS `ra_data_raw_ad_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_data_raw_ad_request` (
  `viewer_id` varchar(32) DEFAULT NULL,
  `viewer_session_id` varchar(32) DEFAULT NULL,
  `date_time` datetime NOT NULL,
  `ad_id` int(10) unsigned NOT NULL,
  `creative_id` int(10) unsigned NOT NULL,
  `zone_id` int(10) unsigned NOT NULL,
  `channel` varchar(255) DEFAULT NULL,
  `channel_ids` varchar(64) DEFAULT NULL,
  `language` varchar(32) DEFAULT NULL,
  `ip_address` varchar(16) DEFAULT NULL,
  `host_name` varchar(255) DEFAULT NULL,
  `https` tinyint(1) DEFAULT NULL,
  `domain` varchar(255) DEFAULT NULL,
  `page` varchar(255) DEFAULT NULL,
  `query` varchar(255) DEFAULT NULL,
  `referer` varchar(255) DEFAULT NULL,
  `search_term` varchar(255) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `os` varchar(32) DEFAULT NULL,
  `browser` varchar(32) DEFAULT NULL,
  `max_https` tinyint(1) DEFAULT NULL,
  KEY `ra_data_raw_ad_request_viewer_id` (`viewer_id`),
  KEY `ra_data_raw_ad_request_date_time` (`date_time`),
  KEY `ra_data_raw_ad_request_ad_id` (`ad_id`),
  KEY `ra_data_raw_ad_request_zone_id` (`zone_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_data_raw_ad_request`
--

LOCK TABLES `ra_data_raw_ad_request` WRITE;
/*!40000 ALTER TABLE `ra_data_raw_ad_request` DISABLE KEYS */;
/*!40000 ALTER TABLE `ra_data_raw_ad_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_data_raw_tracker_impression`
--

DROP TABLE IF EXISTS `ra_data_raw_tracker_impression`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_data_raw_tracker_impression` (
  `server_raw_tracker_impression_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `server_raw_ip` varchar(16) NOT NULL DEFAULT '',
  `viewer_id` varchar(32) NOT NULL DEFAULT '',
  `viewer_session_id` varchar(32) DEFAULT NULL,
  `date_time` datetime NOT NULL,
  `tracker_id` int(10) unsigned NOT NULL,
  `channel` varchar(255) DEFAULT NULL,
  `channel_ids` varchar(64) DEFAULT NULL,
  `language` varchar(32) DEFAULT NULL,
  `ip_address` varchar(16) DEFAULT NULL,
  `host_name` varchar(255) DEFAULT NULL,
  `country` char(2) DEFAULT NULL,
  `https` int(10) unsigned DEFAULT NULL,
  `domain` varchar(255) DEFAULT NULL,
  `page` varchar(255) DEFAULT NULL,
  `query` varchar(255) DEFAULT NULL,
  `referer` varchar(255) DEFAULT NULL,
  `search_term` varchar(255) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `os` varchar(32) DEFAULT NULL,
  `browser` varchar(32) DEFAULT NULL,
  `max_https` int(10) unsigned DEFAULT NULL,
  `geo_region` varchar(50) DEFAULT NULL,
  `geo_city` varchar(50) DEFAULT NULL,
  `geo_postal_code` varchar(10) DEFAULT NULL,
  `geo_latitude` decimal(8,4) DEFAULT NULL,
  `geo_longitude` decimal(8,4) DEFAULT NULL,
  `geo_dma_code` varchar(50) DEFAULT NULL,
  `geo_area_code` varchar(50) DEFAULT NULL,
  `geo_organisation` varchar(50) DEFAULT NULL,
  `geo_netspeed` varchar(20) DEFAULT NULL,
  `geo_continent` varchar(13) DEFAULT NULL,
  PRIMARY KEY (`server_raw_tracker_impression_id`,`server_raw_ip`),
  KEY `ra_data_raw_tracker_impression_viewer_id` (`viewer_id`),
  KEY `ra_data_raw_tracker_impression_date_time` (`date_time`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_data_raw_tracker_impression`
--

LOCK TABLES `ra_data_raw_tracker_impression` WRITE;
/*!40000 ALTER TABLE `ra_data_raw_tracker_impression` DISABLE KEYS */;
/*!40000 ALTER TABLE `ra_data_raw_tracker_impression` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_data_raw_tracker_variable_value`
--

DROP TABLE IF EXISTS `ra_data_raw_tracker_variable_value`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_data_raw_tracker_variable_value` (
  `server_raw_tracker_impression_id` bigint(20) NOT NULL,
  `server_raw_ip` varchar(16) NOT NULL DEFAULT '',
  `tracker_variable_id` int(11) NOT NULL,
  `date_time` datetime DEFAULT NULL,
  `value` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`server_raw_tracker_impression_id`,`server_raw_ip`,`tracker_variable_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_data_raw_tracker_variable_value`
--

LOCK TABLES `ra_data_raw_tracker_variable_value` WRITE;
/*!40000 ALTER TABLE `ra_data_raw_tracker_variable_value` DISABLE KEYS */;
/*!40000 ALTER TABLE `ra_data_raw_tracker_variable_value` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_data_summary_ad_hourly`
--

DROP TABLE IF EXISTS `ra_data_summary_ad_hourly`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_data_summary_ad_hourly` (
  `data_summary_ad_hourly_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date_time` datetime NOT NULL,
  `ad_id` int(10) unsigned NOT NULL,
  `creative_id` int(10) unsigned NOT NULL,
  `zone_id` int(10) unsigned NOT NULL,
  `requests` int(10) unsigned NOT NULL DEFAULT '0',
  `impressions` int(10) unsigned NOT NULL DEFAULT '0',
  `clicks` int(10) unsigned NOT NULL DEFAULT '0',
  `conversions` int(10) unsigned NOT NULL DEFAULT '0',
  `total_basket_value` decimal(10,4) DEFAULT NULL,
  `total_num_items` int(11) DEFAULT NULL,
  `total_revenue` decimal(10,4) DEFAULT NULL,
  `total_cost` decimal(10,4) DEFAULT NULL,
  `total_techcost` decimal(10,4) DEFAULT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`data_summary_ad_hourly_id`),
  KEY `ra_data_summary_ad_hourly_date_time` (`date_time`),
  KEY `ra_data_summary_ad_hourly_ad_id_date_time` (`ad_id`,`date_time`),
  KEY `ra_data_summary_ad_hourly_zone_id_date_time` (`zone_id`,`date_time`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_data_summary_ad_hourly`
--

LOCK TABLES `ra_data_summary_ad_hourly` WRITE;
/*!40000 ALTER TABLE `ra_data_summary_ad_hourly` DISABLE KEYS */;
/*!40000 ALTER TABLE `ra_data_summary_ad_hourly` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_data_summary_ad_zone_assoc`
--

DROP TABLE IF EXISTS `ra_data_summary_ad_zone_assoc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_data_summary_ad_zone_assoc` (
  `data_summary_ad_zone_assoc_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `operation_interval` int(10) unsigned NOT NULL,
  `operation_interval_id` int(10) unsigned NOT NULL,
  `interval_start` datetime NOT NULL,
  `interval_end` datetime NOT NULL,
  `ad_id` int(10) unsigned NOT NULL,
  `zone_id` int(10) unsigned NOT NULL,
  `required_impressions` int(10) unsigned NOT NULL,
  `requested_impressions` int(10) unsigned NOT NULL,
  `priority` double NOT NULL,
  `priority_factor` double DEFAULT NULL,
  `priority_factor_limited` smallint(6) NOT NULL DEFAULT '0',
  `past_zone_traffic_fraction` double DEFAULT NULL,
  `created` datetime NOT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `expired` datetime DEFAULT NULL,
  `expired_by` int(10) unsigned DEFAULT NULL,
  `to_be_delivered` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`data_summary_ad_zone_assoc_id`),
  KEY `ra_data_summary_ad_zone_assoc_interval_start` (`interval_start`),
  KEY `ra_data_summary_ad_zone_assoc_interval_end` (`interval_end`),
  KEY `ra_data_summary_ad_zone_assoc_ad_id` (`ad_id`),
  KEY `ra_data_summary_ad_zone_assoc_zone_id` (`zone_id`),
  KEY `ra_data_summary_ad_zone_assoc_expired` (`expired`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_data_summary_ad_zone_assoc`
--

LOCK TABLES `ra_data_summary_ad_zone_assoc` WRITE;
/*!40000 ALTER TABLE `ra_data_summary_ad_zone_assoc` DISABLE KEYS */;
/*!40000 ALTER TABLE `ra_data_summary_ad_zone_assoc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_data_summary_channel_daily`
--

DROP TABLE IF EXISTS `ra_data_summary_channel_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_data_summary_channel_daily` (
  `data_summary_channel_daily_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `day` date NOT NULL,
  `channel_id` int(10) unsigned NOT NULL,
  `zone_id` int(10) unsigned NOT NULL,
  `forecast_impressions` int(10) unsigned NOT NULL DEFAULT '0',
  `actual_impressions` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`data_summary_channel_daily_id`),
  KEY `ra_data_summary_channel_daily_day` (`day`),
  KEY `ra_data_summary_channel_daily_channel_id` (`channel_id`),
  KEY `ra_data_summary_channel_daily_zone_id` (`zone_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_data_summary_channel_daily`
--

LOCK TABLES `ra_data_summary_channel_daily` WRITE;
/*!40000 ALTER TABLE `ra_data_summary_channel_daily` DISABLE KEYS */;
/*!40000 ALTER TABLE `ra_data_summary_channel_daily` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_data_summary_zone_impression_history`
--

DROP TABLE IF EXISTS `ra_data_summary_zone_impression_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_data_summary_zone_impression_history` (
  `data_summary_zone_impression_history_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `operation_interval` int(10) unsigned NOT NULL,
  `operation_interval_id` int(10) unsigned NOT NULL,
  `interval_start` datetime NOT NULL,
  `interval_end` datetime NOT NULL,
  `zone_id` int(10) unsigned NOT NULL,
  `forecast_impressions` int(10) unsigned DEFAULT NULL,
  `actual_impressions` int(10) unsigned DEFAULT NULL,
  `est` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`data_summary_zone_impression_history_id`),
  KEY `ra_data_summary_zone_impression_history_operation_interval_id` (`operation_interval_id`),
  KEY `ra_data_summary_zone_impression_history_zone_id` (`zone_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_data_summary_zone_impression_history`
--

LOCK TABLES `ra_data_summary_zone_impression_history` WRITE;
/*!40000 ALTER TABLE `ra_data_summary_zone_impression_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `ra_data_summary_zone_impression_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_database_action`
--

DROP TABLE IF EXISTS `ra_database_action`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_database_action` (
  `database_action_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `upgrade_action_id` int(10) unsigned DEFAULT '0',
  `schema_name` varchar(64) DEFAULT NULL,
  `version` int(11) NOT NULL,
  `timing` int(2) NOT NULL,
  `action` int(2) NOT NULL,
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `tablename` varchar(64) DEFAULT NULL,
  `tablename_backup` varchar(64) DEFAULT NULL,
  `table_backup_schema` text,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`database_action_id`),
  KEY `ra_database_action_upgrade_action_id` (`upgrade_action_id`,`database_action_id`),
  KEY `ra_database_action_schema_version_timing_action` (`schema_name`,`version`,`timing`,`action`),
  KEY `ra_database_action_updated` (`updated`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_database_action`
--

LOCK TABLES `ra_database_action` WRITE;
/*!40000 ALTER TABLE `ra_database_action` DISABLE KEYS */;
INSERT INTO `ra_database_action` VALUES (1,24,'oxDeliveryDataPrepare',2,0,59,'CREATE SUCCEEDED',NULL,'data_bkt_c',NULL,NULL,'2014-01-22 10:45:26'),(2,24,'oxDeliveryDataPrepare',2,0,59,'CREATE SUCCEEDED',NULL,'data_bkt_m',NULL,NULL,'2014-01-22 10:45:26'),(3,24,'oxDeliveryDataPrepare',2,0,59,'CREATE SUCCEEDED',NULL,'data_bkt_r',NULL,NULL,'2014-01-22 10:45:26'),(4,24,'oxDeliveryDataPrepare',2,0,59,'CREATE SUCCEEDED',NULL,'data_bkt_a',NULL,NULL,'2014-01-22 10:45:26'),(5,24,'oxDeliveryDataPrepare',2,0,59,'CREATE SUCCEEDED',NULL,'data_bkt_a_var',NULL,NULL,'2014-01-22 10:45:26'),(6,30,'vastbannertypehtml',13,0,59,'CREATE SUCCEEDED',NULL,'banner_vast_element',NULL,NULL,'2014-01-22 10:45:30'),(7,30,'vastbannertypehtml',13,0,59,'CREATE SUCCEEDED',NULL,'data_bkt_vast_e',NULL,NULL,'2014-01-22 10:45:30'),(8,30,'vastbannertypehtml',13,0,59,'CREATE SUCCEEDED',NULL,'stats_vast',NULL,NULL,'2014-01-22 10:45:30');
/*!40000 ALTER TABLE `ra_database_action` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_images`
--

DROP TABLE IF EXISTS `ra_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_images` (
  `filename` varchar(128) NOT NULL DEFAULT '',
  `contents` longblob NOT NULL,
  `t_stamp` datetime DEFAULT NULL,
  PRIMARY KEY (`filename`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_images`
--

LOCK TABLES `ra_images` WRITE;
/*!40000 ALTER TABLE `ra_images` DISABLE KEYS */;
/*!40000 ALTER TABLE `ra_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_log_maintenance_forecasting`
--

DROP TABLE IF EXISTS `ra_log_maintenance_forecasting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_log_maintenance_forecasting` (
  `log_maintenance_forecasting_id` int(11) NOT NULL AUTO_INCREMENT,
  `start_run` datetime NOT NULL,
  `end_run` datetime NOT NULL,
  `operation_interval` int(11) NOT NULL,
  `duration` int(11) NOT NULL,
  `updated_to` datetime DEFAULT NULL,
  PRIMARY KEY (`log_maintenance_forecasting_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_log_maintenance_forecasting`
--

LOCK TABLES `ra_log_maintenance_forecasting` WRITE;
/*!40000 ALTER TABLE `ra_log_maintenance_forecasting` DISABLE KEYS */;
/*!40000 ALTER TABLE `ra_log_maintenance_forecasting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_log_maintenance_priority`
--

DROP TABLE IF EXISTS `ra_log_maintenance_priority`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_log_maintenance_priority` (
  `log_maintenance_priority_id` int(11) NOT NULL AUTO_INCREMENT,
  `start_run` datetime NOT NULL,
  `end_run` datetime NOT NULL,
  `operation_interval` int(11) NOT NULL,
  `duration` int(11) NOT NULL,
  `run_type` tinyint(3) unsigned NOT NULL,
  `updated_to` datetime DEFAULT NULL,
  PRIMARY KEY (`log_maintenance_priority_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_log_maintenance_priority`
--

LOCK TABLES `ra_log_maintenance_priority` WRITE;
/*!40000 ALTER TABLE `ra_log_maintenance_priority` DISABLE KEYS */;
/*!40000 ALTER TABLE `ra_log_maintenance_priority` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_log_maintenance_statistics`
--

DROP TABLE IF EXISTS `ra_log_maintenance_statistics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_log_maintenance_statistics` (
  `log_maintenance_statistics_id` int(11) NOT NULL AUTO_INCREMENT,
  `start_run` datetime NOT NULL,
  `end_run` datetime NOT NULL,
  `duration` int(11) NOT NULL,
  `adserver_run_type` int(2) DEFAULT NULL,
  `search_run_type` int(2) DEFAULT NULL,
  `tracker_run_type` int(2) DEFAULT NULL,
  `updated_to` datetime DEFAULT NULL,
  PRIMARY KEY (`log_maintenance_statistics_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_log_maintenance_statistics`
--

LOCK TABLES `ra_log_maintenance_statistics` WRITE;
/*!40000 ALTER TABLE `ra_log_maintenance_statistics` DISABLE KEYS */;
/*!40000 ALTER TABLE `ra_log_maintenance_statistics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_password_recovery`
--

DROP TABLE IF EXISTS `ra_password_recovery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_password_recovery` (
  `user_type` varchar(64) NOT NULL DEFAULT '',
  `user_id` int(10) NOT NULL,
  `recovery_id` varchar(64) NOT NULL DEFAULT '',
  `updated` datetime NOT NULL,
  PRIMARY KEY (`user_type`,`user_id`),
  UNIQUE KEY `ra_password_recovery_recovery_id` (`recovery_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_password_recovery`
--

LOCK TABLES `ra_password_recovery` WRITE;
/*!40000 ALTER TABLE `ra_password_recovery` DISABLE KEYS */;
/*!40000 ALTER TABLE `ra_password_recovery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_placement_zone_assoc`
--

DROP TABLE IF EXISTS `ra_placement_zone_assoc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_placement_zone_assoc` (
  `placement_zone_assoc_id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `zone_id` mediumint(9) DEFAULT NULL,
  `placement_id` mediumint(9) DEFAULT NULL,
  PRIMARY KEY (`placement_zone_assoc_id`),
  KEY `ra_placement_zone_assoc_zone_id` (`zone_id`),
  KEY `ra_placement_zone_assoc_placement_id` (`placement_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_placement_zone_assoc`
--

LOCK TABLES `ra_placement_zone_assoc` WRITE;
/*!40000 ALTER TABLE `ra_placement_zone_assoc` DISABLE KEYS */;
/*!40000 ALTER TABLE `ra_placement_zone_assoc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_preferences`
--

DROP TABLE IF EXISTS `ra_preferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_preferences` (
  `preference_id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `preference_name` varchar(64) NOT NULL DEFAULT '',
  `account_type` varchar(16) NOT NULL DEFAULT '',
  PRIMARY KEY (`preference_id`),
  UNIQUE KEY `ra_preferences_preference_name` (`preference_name`),
  KEY `ra_preferences_account_type` (`account_type`)
) ENGINE=MyISAM AUTO_INCREMENT=98 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_preferences`
--

LOCK TABLES `ra_preferences` WRITE;
/*!40000 ALTER TABLE `ra_preferences` DISABLE KEYS */;
INSERT INTO `ra_preferences` VALUES (1,'default_banner_image_url','TRAFFICKER'),(2,'default_banner_destination_url','TRAFFICKER'),(3,'default_banner_weight','ADVERTISER'),(4,'default_campaign_weight','ADVERTISER'),(5,'warn_email_admin','ADMIN'),(6,'warn_email_admin_impression_limit','ADMIN'),(7,'warn_email_admin_day_limit','ADMIN'),(8,'campaign_ecpm_enabled','MANAGER'),(9,'contract_ecpm_enabled','MANAGER'),(10,'warn_email_manager','MANAGER'),(11,'warn_email_manager_impression_limit','MANAGER'),(12,'warn_email_manager_day_limit','MANAGER'),(13,'warn_email_advertiser','ADVERTISER'),(14,'warn_email_advertiser_impression_limit','ADVERTISER'),(15,'warn_email_advertiser_day_limit','ADVERTISER'),(16,'timezone','MANAGER'),(17,'tracker_default_status','ADVERTISER'),(18,'tracker_default_type','ADVERTISER'),(19,'tracker_link_campaigns','ADVERTISER'),(20,'ui_show_campaign_info','ADVERTISER'),(21,'ui_show_banner_info','ADVERTISER'),(22,'ui_show_campaign_preview','ADVERTISER'),(23,'ui_show_banner_html','ADVERTISER'),(24,'ui_show_banner_preview','ADVERTISER'),(25,'ui_hide_inactive',''),(26,'ui_show_matching_banners','TRAFFICKER'),(27,'ui_show_matching_banners_parents','TRAFFICKER'),(28,'ui_show_entity_id',''),(29,'ui_novice_user',''),(30,'ui_week_start_day',''),(31,'ui_percentage_decimals',''),(32,'ui_column_revenue','MANAGER'),(33,'ui_column_revenue_label','MANAGER'),(34,'ui_column_revenue_rank','MANAGER'),(35,'ui_column_bv','MANAGER'),(36,'ui_column_bv_label','MANAGER'),(37,'ui_column_bv_rank','MANAGER'),(38,'ui_column_num_items','MANAGER'),(39,'ui_column_num_items_label','MANAGER'),(40,'ui_column_num_items_rank','MANAGER'),(41,'ui_column_revcpc','MANAGER'),(42,'ui_column_revcpc_label','MANAGER'),(43,'ui_column_revcpc_rank','MANAGER'),(44,'ui_column_erpm','MANAGER'),(45,'ui_column_erpm_label','MANAGER'),(46,'ui_column_erpm_rank','MANAGER'),(47,'ui_column_erpc','MANAGER'),(48,'ui_column_erpc_label','MANAGER'),(49,'ui_column_erpc_rank','MANAGER'),(50,'ui_column_erps','MANAGER'),(51,'ui_column_erps_label','MANAGER'),(52,'ui_column_erps_rank','MANAGER'),(53,'ui_column_eipm','MANAGER'),(54,'ui_column_eipm_label','MANAGER'),(55,'ui_column_eipm_rank','MANAGER'),(56,'ui_column_eipc','MANAGER'),(57,'ui_column_eipc_label','MANAGER'),(58,'ui_column_eipc_rank','MANAGER'),(59,'ui_column_eips','MANAGER'),(60,'ui_column_eips_label','MANAGER'),(61,'ui_column_eips_rank','MANAGER'),(62,'ui_column_ecpm','MANAGER'),(63,'ui_column_ecpm_label','MANAGER'),(64,'ui_column_ecpm_rank','MANAGER'),(65,'ui_column_ecpc','MANAGER'),(66,'ui_column_ecpc_label','MANAGER'),(67,'ui_column_ecpc_rank','MANAGER'),(68,'ui_column_ecps','MANAGER'),(69,'ui_column_ecps_label','MANAGER'),(70,'ui_column_ecps_rank','MANAGER'),(71,'ui_column_id','MANAGER'),(72,'ui_column_id_label','MANAGER'),(73,'ui_column_id_rank','MANAGER'),(74,'ui_column_requests','MANAGER'),(75,'ui_column_requests_label','MANAGER'),(76,'ui_column_requests_rank','MANAGER'),(77,'ui_column_impressions','MANAGER'),(78,'ui_column_impressions_label','MANAGER'),(79,'ui_column_impressions_rank','MANAGER'),(80,'ui_column_clicks','MANAGER'),(81,'ui_column_clicks_label','MANAGER'),(82,'ui_column_clicks_rank','MANAGER'),(83,'ui_column_ctr','MANAGER'),(84,'ui_column_ctr_label','MANAGER'),(85,'ui_column_ctr_rank','MANAGER'),(86,'ui_column_conversions','MANAGER'),(87,'ui_column_conversions_label','MANAGER'),(88,'ui_column_conversions_rank','MANAGER'),(89,'ui_column_conversions_pending','MANAGER'),(90,'ui_column_conversions_pending_label','MANAGER'),(91,'ui_column_conversions_pending_rank','MANAGER'),(92,'ui_column_sr_views','MANAGER'),(93,'ui_column_sr_views_label','MANAGER'),(94,'ui_column_sr_views_rank','MANAGER'),(95,'ui_column_sr_clicks','MANAGER'),(96,'ui_column_sr_clicks_label','MANAGER'),(97,'ui_column_sr_clicks_rank','MANAGER');
/*!40000 ALTER TABLE `ra_preferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_session`
--

DROP TABLE IF EXISTS `ra_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_session` (
  `sessionid` varchar(32) NOT NULL DEFAULT '',
  `sessiondata` text NOT NULL,
  `lastused` datetime DEFAULT NULL,
  PRIMARY KEY (`sessionid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_session`
--

LOCK TABLES `ra_session` WRITE;
/*!40000 ALTER TABLE `ra_session` DISABLE KEYS */;
INSERT INTO `ra_session` VALUES ('a2ab8ec1250457fe2c74f27039a46e42','a:4:{s:4:\"user\";O:18:\"OA_Permission_User\":2:{s:5:\"aUser\";a:13:{s:7:\"user_id\";s:1:\"1\";s:12:\"contact_name\";s:13:\"Administrator\";s:13:\"email_address\";s:49:\"afrikatec@p3plcpnl0454.prod.phx3.secureserver.net\";s:8:\"username\";s:5:\"admin\";s:8:\"language\";s:2:\"en\";s:18:\"default_account_id\";s:1:\"2\";s:8:\"comments\";s:0:\"\";s:6:\"active\";s:1:\"1\";s:11:\"sso_user_id\";s:0:\"\";s:12:\"date_created\";s:19:\"2014-01-22 04:45:00\";s:15:\"date_last_login\";s:19:\"2015-03-21 02:36:44\";s:13:\"email_updated\";s:19:\"2014-01-22 04:45:00\";s:8:\"is_admin\";b:1;}s:8:\"aAccount\";a:7:{s:10:\"account_id\";s:1:\"2\";s:12:\"account_type\";s:7:\"MANAGER\";s:12:\"account_name\";s:15:\"Default manager\";s:12:\"m2m_password\";s:0:\"\";s:10:\"m2m_ticket\";s:0:\"\";s:9:\"entity_id\";s:1:\"1\";s:9:\"agency_id\";s:1:\"1\";}}s:5:\"prefs\";a:3:{s:7:\"GLOBALS\";a:3:{s:13:\"period_preset\";s:5:\"today\";s:12:\"period_start\";s:10:\"2015-03-20\";s:10:\"period_end\";s:10:\"2015-03-20\";}s:9:\"stats.php\";a:5:{s:9:\"listorder\";s:4:\"name\";s:14:\"orderdirection\";s:2:\"up\";s:10:\"startlevel\";i:0;s:5:\"nodes\";s:0:\"\";s:12:\"hideinactive\";b:0;}s:20:\"advertiser-index.php\";a:3:{s:12:\"hideinactive\";b:0;s:9:\"listorder\";s:0:\"\";s:14:\"orderdirection\";s:0:\"\";}}s:17:\"notificationQueue\";a:0:{}s:5:\"token\";s:32:\"0e72a5c68033c5f4c830759351735006\";}','2015-03-21 02:37:18');
/*!40000 ALTER TABLE `ra_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_stats_vast`
--

DROP TABLE IF EXISTS `ra_stats_vast`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_stats_vast` (
  `interval_start` datetime NOT NULL,
  `creative_id` mediumint(20) NOT NULL,
  `zone_id` mediumint(20) NOT NULL,
  `vast_event_id` mediumint(20) NOT NULL,
  `count` int(11) NOT NULL DEFAULT '0',
  KEY `ra_stats_vast_creativekey` (`interval_start`,`creative_id`),
  KEY `ra_stats_vast_zonekey` (`interval_start`,`zone_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_stats_vast`
--

LOCK TABLES `ra_stats_vast` WRITE;
/*!40000 ALTER TABLE `ra_stats_vast` DISABLE KEYS */;
/*!40000 ALTER TABLE `ra_stats_vast` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_targetstats`
--

DROP TABLE IF EXISTS `ra_targetstats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_targetstats` (
  `day` date NOT NULL DEFAULT '0000-00-00',
  `campaignid` mediumint(9) NOT NULL DEFAULT '0',
  `target` int(11) NOT NULL DEFAULT '0',
  `views` int(11) NOT NULL DEFAULT '0',
  `modified` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_targetstats`
--

LOCK TABLES `ra_targetstats` WRITE;
/*!40000 ALTER TABLE `ra_targetstats` DISABLE KEYS */;
/*!40000 ALTER TABLE `ra_targetstats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_tracker_append`
--

DROP TABLE IF EXISTS `ra_tracker_append`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_tracker_append` (
  `tracker_append_id` int(11) NOT NULL AUTO_INCREMENT,
  `tracker_id` mediumint(9) NOT NULL DEFAULT '0',
  `rank` int(11) NOT NULL DEFAULT '0',
  `tagcode` text NOT NULL,
  `paused` enum('t','f') NOT NULL DEFAULT 'f',
  `autotrack` enum('t','f') NOT NULL DEFAULT 'f',
  PRIMARY KEY (`tracker_append_id`),
  KEY `ra_tracker_append_tracker_id` (`tracker_id`,`rank`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_tracker_append`
--

LOCK TABLES `ra_tracker_append` WRITE;
/*!40000 ALTER TABLE `ra_tracker_append` DISABLE KEYS */;
/*!40000 ALTER TABLE `ra_tracker_append` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_trackers`
--

DROP TABLE IF EXISTS `ra_trackers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_trackers` (
  `trackerid` mediumint(9) NOT NULL AUTO_INCREMENT,
  `trackername` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `clientid` mediumint(9) NOT NULL DEFAULT '0',
  `viewwindow` mediumint(9) NOT NULL DEFAULT '0',
  `clickwindow` mediumint(9) NOT NULL DEFAULT '0',
  `blockwindow` mediumint(9) NOT NULL DEFAULT '0',
  `status` smallint(1) unsigned NOT NULL DEFAULT '4',
  `type` smallint(1) unsigned NOT NULL DEFAULT '1',
  `linkcampaigns` enum('t','f') NOT NULL DEFAULT 'f',
  `variablemethod` enum('default','js','dom','custom') NOT NULL DEFAULT 'default',
  `appendcode` text NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`trackerid`),
  KEY `ra_trackers_clientid` (`clientid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_trackers`
--

LOCK TABLES `ra_trackers` WRITE;
/*!40000 ALTER TABLE `ra_trackers` DISABLE KEYS */;
/*!40000 ALTER TABLE `ra_trackers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_upgrade_action`
--

DROP TABLE IF EXISTS `ra_upgrade_action`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_upgrade_action` (
  `upgrade_action_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `upgrade_name` varchar(128) DEFAULT NULL,
  `version_to` varchar(64) NOT NULL DEFAULT '',
  `version_from` varchar(64) DEFAULT NULL,
  `action` int(2) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `logfile` varchar(128) DEFAULT NULL,
  `confbackup` varchar(128) DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`upgrade_action_id`),
  KEY `ra_upgrade_action_updated` (`updated`)
) ENGINE=MyISAM AUTO_INCREMENT=65 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_upgrade_action`
--

LOCK TABLES `ra_upgrade_action` WRITE;
/*!40000 ALTER TABLE `ra_upgrade_action` DISABLE KEYS */;
INSERT INTO `ra_upgrade_action` VALUES (1,'install_3.0.2','3.0.2','0',1,'UPGRADE_COMPLETE','install.log',NULL,'2014-01-22 04:44:51'),(2,'install_openXBannerTypes','1.1.0','0',4,'PACKAGE INSTALL COMPLETE','plugins.log',NULL,'2014-01-22 10:45:02'),(3,'install_oxHtml','1.1.0','0',4,'PLUGIN INSTALL COMPLETE','plugins.log',NULL,'2014-01-22 10:45:02'),(4,'install_oxText','1.1.0','0',4,'PLUGIN INSTALL COMPLETE','plugins.log',NULL,'2014-01-22 10:45:02'),(5,'install_openXDeliveryLimitations','1.1.0','0',4,'PACKAGE INSTALL COMPLETE','plugins.log',NULL,'2014-01-22 10:45:05'),(6,'install_Client','1.1.0','0',4,'PLUGIN INSTALL COMPLETE','plugins.log',NULL,'2014-01-22 10:45:05'),(7,'install_Geo','1.1.0','0',4,'PLUGIN INSTALL COMPLETE','plugins.log',NULL,'2014-01-22 10:45:05'),(8,'install_Site','1.1.0','0',4,'PLUGIN INSTALL COMPLETE','plugins.log',NULL,'2014-01-22 10:45:05'),(9,'install_Time','1.1.0','0',4,'PLUGIN INSTALL COMPLETE','plugins.log',NULL,'2014-01-22 10:45:05'),(10,'install_openX3rdPartyServers','1.1.0','0',4,'PACKAGE INSTALL COMPLETE','plugins.log',NULL,'2014-01-22 10:45:08'),(11,'install_ox3rdPartyServers','1.1.0','0',4,'PLUGIN INSTALL COMPLETE','plugins.log',NULL,'2014-01-22 10:45:08'),(12,'install_openXReports','1.4.1','0',4,'PACKAGE INSTALL COMPLETE','plugins.log',NULL,'2014-01-22 10:45:11'),(13,'install_oxReportsStandard','1.4.0','0',4,'PLUGIN INSTALL COMPLETE','plugins.log',NULL,'2014-01-22 10:45:11'),(14,'install_oxReportsAdmin','1.4.0','0',4,'PLUGIN INSTALL COMPLETE','plugins.log',NULL,'2014-01-22 10:45:11'),(15,'install_openXDeliveryCacheStore','1.1.0','0',4,'PACKAGE INSTALL COMPLETE','plugins.log',NULL,'2014-01-22 10:45:15'),(16,'install_oxCacheFile','1.1.0','0',4,'PLUGIN INSTALL COMPLETE','plugins.log',NULL,'2014-01-22 10:45:15'),(17,'install_oxMemcached','1.1.0','0',4,'PLUGIN INSTALL COMPLETE','plugins.log',NULL,'2014-01-22 10:45:15'),(18,'install_openXMaxMindGeoIP','1.1.0','0',4,'PACKAGE INSTALL COMPLETE','plugins.log',NULL,'2014-01-22 10:45:19'),(19,'install_oxMaxMindGeoIP','1.1.0','0',4,'PLUGIN INSTALL COMPLETE','plugins.log',NULL,'2014-01-22 10:45:19'),(20,'install_openXInvocationTags','1.1.0','0',4,'PACKAGE INSTALL COMPLETE','plugins.log',NULL,'2014-01-22 10:45:22'),(21,'install_oxInvocationTags','1.1.0','0',4,'PLUGIN INSTALL COMPLETE','plugins.log',NULL,'2014-01-22 10:45:22'),(22,'install_openXDeliveryLog','1.1.0','0',4,'PACKAGE INSTALL COMPLETE','plugins.log',NULL,'2014-01-22 10:45:27'),(23,'install_oxDeliveryDataPrepare','1.1.0','0',4,'PLUGIN INSTALL COMPLETE','plugins.log',NULL,'2014-01-22 10:45:26'),(24,'install_oxLogClick','1.1.0','0',4,'PLUGIN INSTALL COMPLETE','plugins.log',NULL,'2014-01-22 10:45:26'),(25,'install_oxLogConversion','1.1.0','0',4,'PLUGIN INSTALL COMPLETE','plugins.log',NULL,'2014-01-22 10:45:26'),(26,'install_oxLogImpression','1.1.0','0',4,'PLUGIN INSTALL COMPLETE','plugins.log',NULL,'2014-01-22 10:45:26'),(27,'install_oxLogRequest','1.1.0','0',4,'PLUGIN INSTALL COMPLETE','plugins.log',NULL,'2014-01-22 10:45:26'),(28,'install_openXVideoAds','1.9.1','0',4,'PACKAGE INSTALL COMPLETE','plugins.log',NULL,'2014-01-22 10:45:31'),(29,'install_vastInlineBannerTypeHtml','1.9.1','0',4,'PLUGIN INSTALL COMPLETE','plugins.log',NULL,'2014-01-22 10:45:30'),(30,'install_vastOverlayBannerTypeHtml','1.9.1','0',4,'PLUGIN INSTALL COMPLETE','plugins.log',NULL,'2014-01-22 10:45:30'),(31,'install_oxLogVast','1.9.1','0',4,'PLUGIN INSTALL COMPLETE','plugins.log',NULL,'2014-01-22 10:45:30'),(32,'install_vastServeVideoPlayer','1.9.1','0',4,'PLUGIN INSTALL COMPLETE','plugins.log',NULL,'2014-01-22 10:45:30'),(33,'install_videoReport','1.9.1','0',4,'PLUGIN INSTALL COMPLETE','plugins.log',NULL,'2014-01-22 10:45:30'),(34,'openads_version_stamp_3.0.5','3.0.5','3.0.2',1,'UPGRADE_COMPLETE','openads_version_stamp_3.0.5_2015_05_07_11_50_15.log','20150507_old.dweretech.com.conf.php','2015-05-07 23:50:16'),(35,'upgrade_openXBannerTypes','1.2.1','1.1.0',1,'UPGRADE COMPLETE','plugins.log',NULL,'2015-05-07 23:50:18'),(36,'oxHtml_version_stamp_1.2.1','1.2.1','1.1.0',1,'UPGRADE COMPLETE','oxHtml_upgrade.log',NULL,'2015-05-07 23:50:18'),(37,'oxText_version_stamp_1.2.1','1.2.1','1.1.0',1,'UPGRADE COMPLETE','oxText_upgrade.log',NULL,'2015-05-07 23:50:18'),(38,'upgrade_openXDeliveryLimitations','1.2.1','1.1.0',1,'UPGRADE COMPLETE','plugins.log',NULL,'2015-05-07 23:50:22'),(39,'Client_version_stamp_1.2.1','1.2.1','1.1.0',1,'UPGRADE COMPLETE','Client_upgrade.log',NULL,'2015-05-07 23:50:22'),(40,'Geo_version_stamp_1.2.1','1.2.1','1.1.0',1,'UPGRADE COMPLETE','Geo_upgrade.log',NULL,'2015-05-07 23:50:22'),(41,'Site_version_stamp_1.2.1','1.2.1','1.1.0',1,'UPGRADE COMPLETE','Site_upgrade.log',NULL,'2015-05-07 23:50:22'),(42,'Time_version_stamp_1.2.1','1.2.1','1.1.0',1,'UPGRADE COMPLETE','Time_upgrade.log',NULL,'2015-05-07 23:50:22'),(43,'upgrade_openXReports','1.5.1','1.4.1',1,'UPGRADE COMPLETE','plugins.log',NULL,'2015-05-07 23:50:29'),(44,'oxReportsStandard_version_stamp_1.5.1','1.5.1','1.4.0',1,'UPGRADE COMPLETE','oxReportsStandard_upgrade.log',NULL,'2015-05-07 23:50:29'),(45,'oxReportsAdmin_version_stamp_1.5.1','1.5.1','1.4.0',1,'UPGRADE COMPLETE','oxReportsAdmin_upgrade.log',NULL,'2015-05-07 23:50:29'),(46,'upgrade_openXDeliveryCacheStore','1.1.1','1.1.0',1,'UPGRADE COMPLETE','plugins.log',NULL,'2015-05-07 23:50:33'),(47,'oxCacheFile_version_stamp_1.1.1','1.1.1','1.1.0',1,'UPGRADE COMPLETE','oxCacheFile_upgrade.log',NULL,'2015-05-07 23:50:32'),(48,'oxMemcached_version_stamp_1.1.1','1.1.1','1.1.0',1,'UPGRADE COMPLETE','oxMemcached_upgrade.log',NULL,'2015-05-07 23:50:33'),(49,'upgrade_openXMaxMindGeoIP','1.2.2','1.1.0',1,'UPGRADE COMPLETE','plugins.log',NULL,'2015-05-07 23:50:36'),(50,'oxMaxMindGeoIP_version_stamp_1.2.2','1.2.2','1.1.0',1,'UPGRADE COMPLETE','oxMaxMindGeoIP_upgrade.log',NULL,'2015-05-07 23:50:36'),(51,'upgrade_openXInvocationTags','1.2.1','1.1.0',1,'UPGRADE COMPLETE','plugins.log',NULL,'2015-05-07 23:50:40'),(52,'oxInvocationTags_version_stamp_1.2.1','1.2.1','1.1.0',1,'UPGRADE COMPLETE','oxInvocationTags_upgrade.log',NULL,'2015-05-07 23:50:40'),(53,'upgrade_openXDeliveryLog','1.1.1','1.1.0',1,'UPGRADE COMPLETE','plugins.log',NULL,'2015-05-07 23:50:46'),(54,'oxDeliveryDataPrepare_version_stamp_1.1.1','1.1.1','1.1.0',1,'UPGRADE COMPLETE','oxDeliveryDataPrepare_upgrade.log',NULL,'2015-05-07 23:50:45'),(55,'oxLogClick_version_stamp_1.1.1','1.1.1','1.1.0',1,'UPGRADE COMPLETE','oxLogClick_upgrade.log',NULL,'2015-05-07 23:50:46'),(56,'oxLogConversion_version_stamp_1.1.1','1.1.1','1.1.0',1,'UPGRADE COMPLETE','oxLogConversion_upgrade.log',NULL,'2015-05-07 23:50:46'),(57,'oxLogImpression_version_stamp_1.1.1','1.1.1','1.1.0',1,'UPGRADE COMPLETE','oxLogImpression_upgrade.log',NULL,'2015-05-07 23:50:46'),(58,'oxLogRequest_version_stamp_1.1.1','1.1.1','1.1.0',1,'UPGRADE COMPLETE','oxLogRequest_upgrade.log',NULL,'2015-05-07 23:50:46'),(59,'upgrade_openXVideoAds','1.10.2','1.9.1',1,'UPGRADE COMPLETE','plugins.log',NULL,'2015-05-07 23:50:52'),(60,'vastInlineBannerTypeHtml_version_stamp_1.10.2','1.10.2','1.9.1',1,'UPGRADE COMPLETE','vastInlineBannerTypeHtml_upgrade.log',NULL,'2015-05-07 23:50:52'),(61,'vastOverlayBannerTypeHtml_version_stamp_1.10.2','1.10.2','1.9.1',1,'UPGRADE COMPLETE','vastOverlayBannerTypeHtml_upgrade.log',NULL,'2015-05-07 23:50:52'),(62,'oxLogVast_version_stamp_1.10.2','1.10.2','1.9.1',1,'UPGRADE COMPLETE','oxLogVast_upgrade.log',NULL,'2015-05-07 23:50:52'),(63,'vastServeVideoPlayer_version_stamp_1.10.2','1.10.2','1.9.1',1,'UPGRADE COMPLETE','vastServeVideoPlayer_upgrade.log',NULL,'2015-05-07 23:50:52'),(64,'videoReport_version_stamp_1.10.2','1.10.2','1.9.1',1,'UPGRADE COMPLETE','videoReport_upgrade.log',NULL,'2015-05-07 23:50:52');
/*!40000 ALTER TABLE `ra_upgrade_action` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_userlog`
--

DROP TABLE IF EXISTS `ra_userlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_userlog` (
  `userlogid` mediumint(9) NOT NULL AUTO_INCREMENT,
  `timestamp` int(11) NOT NULL DEFAULT '0',
  `usertype` tinyint(4) NOT NULL DEFAULT '0',
  `userid` mediumint(9) NOT NULL DEFAULT '0',
  `action` mediumint(9) NOT NULL DEFAULT '0',
  `object` mediumint(9) DEFAULT NULL,
  `details` mediumtext,
  PRIMARY KEY (`userlogid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_userlog`
--

LOCK TABLES `ra_userlog` WRITE;
/*!40000 ALTER TABLE `ra_userlog` DISABLE KEYS */;
/*!40000 ALTER TABLE `ra_userlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_users`
--

DROP TABLE IF EXISTS `ra_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_users` (
  `user_id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `contact_name` varchar(255) NOT NULL DEFAULT '',
  `email_address` varchar(64) NOT NULL DEFAULT '',
  `username` varchar(64) DEFAULT NULL,
  `password` varchar(64) DEFAULT NULL,
  `language` varchar(5) DEFAULT NULL,
  `default_account_id` mediumint(9) DEFAULT NULL,
  `comments` text,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `sso_user_id` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_last_login` datetime DEFAULT NULL,
  `email_updated` datetime DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `ra_users_username` (`username`),
  UNIQUE KEY `ra_users_sso_user_id` (`sso_user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_users`
--

LOCK TABLES `ra_users` WRITE;
/*!40000 ALTER TABLE `ra_users` DISABLE KEYS */;
INSERT INTO `ra_users` VALUES (1,'Administrator','afrikatec@p3plcpnl0454.prod.phx3.secureserver.net','admin','cb5d844b31667e085747ed0253a9993b','en',2,NULL,1,NULL,'2014-01-22 04:45:00','2015-03-21 02:36:44','2014-01-22 04:45:00');
/*!40000 ALTER TABLE `ra_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_variable_publisher`
--

DROP TABLE IF EXISTS `ra_variable_publisher`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_variable_publisher` (
  `variable_id` int(11) NOT NULL,
  `publisher_id` int(11) NOT NULL,
  `visible` tinyint(1) NOT NULL,
  PRIMARY KEY (`variable_id`,`publisher_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_variable_publisher`
--

LOCK TABLES `ra_variable_publisher` WRITE;
/*!40000 ALTER TABLE `ra_variable_publisher` DISABLE KEYS */;
/*!40000 ALTER TABLE `ra_variable_publisher` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_variables`
--

DROP TABLE IF EXISTS `ra_variables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_variables` (
  `variableid` mediumint(9) unsigned NOT NULL AUTO_INCREMENT,
  `trackerid` mediumint(9) NOT NULL DEFAULT '0',
  `name` varchar(250) NOT NULL DEFAULT '',
  `description` varchar(250) DEFAULT NULL,
  `datatype` enum('numeric','string','date') NOT NULL DEFAULT 'numeric',
  `purpose` enum('basket_value','num_items','post_code') DEFAULT NULL,
  `reject_if_empty` smallint(1) unsigned NOT NULL DEFAULT '0',
  `is_unique` int(11) NOT NULL DEFAULT '0',
  `unique_window` int(11) NOT NULL DEFAULT '0',
  `variablecode` varchar(255) NOT NULL DEFAULT '',
  `hidden` enum('t','f') NOT NULL DEFAULT 'f',
  `updated` datetime NOT NULL,
  PRIMARY KEY (`variableid`),
  KEY `ra_variables_is_unique` (`is_unique`),
  KEY `ra_variables_trackerid` (`trackerid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_variables`
--

LOCK TABLES `ra_variables` WRITE;
/*!40000 ALTER TABLE `ra_variables` DISABLE KEYS */;
/*!40000 ALTER TABLE `ra_variables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ra_zones`
--

DROP TABLE IF EXISTS `ra_zones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ra_zones` (
  `zoneid` mediumint(9) NOT NULL AUTO_INCREMENT,
  `affiliateid` mediumint(9) DEFAULT NULL,
  `zonename` varchar(245) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `delivery` smallint(6) NOT NULL DEFAULT '0',
  `zonetype` smallint(6) NOT NULL DEFAULT '0',
  `category` text NOT NULL,
  `width` smallint(6) NOT NULL DEFAULT '0',
  `height` smallint(6) NOT NULL DEFAULT '0',
  `ad_selection` text NOT NULL,
  `chain` text NOT NULL,
  `prepend` text NOT NULL,
  `append` text NOT NULL,
  `appendtype` tinyint(4) NOT NULL DEFAULT '0',
  `forceappend` enum('t','f') DEFAULT 'f',
  `inventory_forecast_type` smallint(6) NOT NULL DEFAULT '0',
  `comments` text,
  `cost` decimal(10,4) DEFAULT NULL,
  `cost_type` smallint(6) DEFAULT NULL,
  `cost_variable_id` varchar(255) DEFAULT NULL,
  `technology_cost` decimal(10,4) DEFAULT NULL,
  `technology_cost_type` smallint(6) DEFAULT NULL,
  `updated` datetime NOT NULL,
  `block` int(11) NOT NULL DEFAULT '0',
  `capping` int(11) NOT NULL DEFAULT '0',
  `session_capping` int(11) NOT NULL DEFAULT '0',
  `what` text NOT NULL,
  `as_zone_id` int(11) DEFAULT NULL,
  `is_in_ad_direct` tinyint(1) NOT NULL DEFAULT '0',
  `rate` decimal(19,2) DEFAULT NULL,
  `pricing` varchar(50) NOT NULL DEFAULT 'CPM',
  `oac_category_id` int(11) DEFAULT NULL,
  `ext_adselection` varchar(255) DEFAULT NULL,
  `show_capped_no_cookie` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`zoneid`),
  KEY `ra_zones_zonenameid` (`zonename`,`zoneid`),
  KEY `ra_zones_affiliateid` (`affiliateid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ra_zones`
--

LOCK TABLES `ra_zones` WRITE;
/*!40000 ALTER TABLE `ra_zones` DISABLE KEYS */;
/*!40000 ALTER TABLE `ra_zones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'i755997_ra1'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-05-17 13:57:48
